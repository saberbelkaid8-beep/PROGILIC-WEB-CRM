
// Global error logging and diagnostic screen for developers and users
function showErrorScreen(error, type = "خطأ غير متوقع") {
  const app = document.getElementById('app');
  if (app) {
    const isFrench = S.lang === 'fr';
    const isEnglish = S.lang === 'en';
    const direction = S.lang === 'ar' ? 'rtl' : 'ltr';
    const errorDetails = error ? (error.stack || error.message || String(error)) : (isFrench ? 'Aucun détail disponible' : isEnglish ? 'No details available' : 'تفاصيل غير متوفرة');
    const safeErrorDetails = String(errorDetails).replace(/[&<>"']/g, character => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
    })[character]);
    app.innerHTML = `
      <div style="display:flex; flex-direction:column; align-items:center; justify-content:center; min-height:100vh; padding:24px; font-family:system-ui, -apple-system, sans-serif; background:#f8fafc; color:#1e293b; direction:${direction}; text-align:center;">
        <div style="background:#ffffff; border:1px solid #e2e8f0; border-radius:16px; padding:32px; max-width:500px; width:100%; box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.05);">
          <div style="font-size:48px; margin-bottom:16px;">⚠️</div>
          <h2 style="font-size:20px; font-weight:700; margin-bottom:8px; color:#0f172a;">${isFrench ? 'Une erreur est survenue au démarrage du système' : isEnglish ? 'An error occurred while starting the application' : 'عذراً، حدث خطأ أثناء تشغيل النظام'}</h2>
          <p style="font-size:14px; color:#64748b; margin-bottom:20px; line-height:1.6;">
            ${isFrench ? 'Cela peut être dû aux paramètres de confidentialité du navigateur, au blocage du stockage en mode privé ou à un problème temporaire de synchronisation. Actualisez la page ou videz le cache.' : isEnglish ? 'This may be caused by browser privacy settings, blocked storage in private browsing, or a temporary synchronization issue. Refresh the page or clear the cache.' : 'قد يكون ذلك بسبب قيود الخصوصية في هذا المتصفح، أو حظر الملفات المؤقتة في وضع المتصفح الخفي، أو مشكلة مؤقتة في المزامنة. يرجى محاولة تحديث الصفحة أو مسح الذاكرة المؤقتة.'}
          </p>
          <div style="background:#f1f5f9; border-radius:8px; padding:12px; margin-bottom:24px; font-family:monospace; font-size:11px; color:#475569; text-align:left; overflow-x:auto; white-space:pre-wrap; max-height:120px; border:1px solid #cbd5e1;">
            <strong>[${isFrench ? 'Erreur' : isEnglish ? 'Error' : type}]</strong>: ${safeErrorDetails}
          </div>
          <div style="display:flex; gap:12px; justify-content:center;">
            <button onclick="window.location.reload()" style="background:#1a73e8; color:#ffffff; border:none; padding:10px 20px; border-radius:8px; font-size:14px; font-weight:600; cursor:pointer; transition:background 0.2s;">
              ${isFrench ? 'Actualiser la page' : isEnglish ? 'Refresh page' : 'تحديث الصفحة'}
            </button>
            <button onclick="try { localStorage.clear(); sessionStorage.clear(); window.location.reload(); } catch(e) { window.location.reload(); }" style="background:transparent; color:#64748b; border:1px solid #cbd5e1; padding:10px 20px; border-radius:8px; font-size:14px; font-weight:600; cursor:pointer; transition:background 0.2s;">
              ${isFrench ? 'Vider le cache et actualiser' : isEnglish ? 'Clear cache and reload' : 'مسح الذاكرة وتحديث'}
            </button>
          </div>
        </div>
        <div style="margin-top:16px; font-size:12px; color:#94a3b8;">PROGILIC CRM v3</div>
      </div>
    `;
  }
}

if (typeof window !== 'undefined') {
  window.addEventListener('unhandledrejection', event => {
    console.warn("Unhandled rejection caught:", event.reason);
    const reasonStr = String(event.reason || '');
    if (reasonStr.includes('permission-denied') || reasonStr.includes('insufficient permissions') || (typeof S !== 'undefined' && !S.currentUser)) {
      return;
    }
    const app = document.getElementById('app');
    if (app && (!app.innerHTML || app.innerHTML.includes('Connecting to Secure Cloud Database'))) {
      showErrorScreen(event.reason, "خطأ مزامنة غير معالج");
    }
  });

  window.addEventListener('error', event => {
    console.warn("Uncaught error caught:", event.error || event.message);
    const reasonStr = String(event.error?.message || event.message || '');
    if (reasonStr.includes('permission-denied') || reasonStr.includes('insufficient permissions') || (typeof S !== 'undefined' && !S.currentUser)) {
      return;
    }
    const app = document.getElementById('app');
    if (app && (!app.innerHTML || app.innerHTML.includes('Connecting to Secure Cloud Database'))) {
      showErrorScreen(event.error || event.message, "خطأ تشغيل قاتل");
    }
  });
}

import './css/main.css';
import './css/components.css';
import './css/responsive.css';
import './css/dashboard.css';
import './firebase/config.js';
import * as actions from './business/actions.js';
import { R } from './presentation/render-core.js';
import { updateActTypeOpts, updateCommunesOpts, updateProgramTypeSelect, onClientStatusChange } from './utils/index.js';
import { exportData, exportToDump, exportToCSV, importData, importFromDump, triggerImportDumOrJson, clearAllData, resolveConflict } from './business/storage.js';
import { toggleLanguage, setLanguage, applyLanguageToDocument, fetchMachineTranslation, localizeRenderedDom } from './utils/i18n.js';
import { initAiAssistantWidget } from './presentation/ai/assistantWidget.js';
import { createDefaultGerant } from './constants/index.js';

import { onAuthStateChanged, verifyPasswordResetCode } from 'firebase/auth';
import { auth } from './firebase/config.js';
import { S, setCurrentUser, setCurrentStaffUser, currentStaffUser, clients, getClients, setClients, subscribe, updateState } from './state/store.js';
import { loadDataFromFirestore, stopRealtimeSync, startRealtimeSync, flushSyncQueue, loadCache } from './business/storage.js';
import { getStoredEmployeeSession, hasPermission } from './business/employeeService.js';

// Subscribe render-core's R function to state changes for automatic reactivity
subscribe(R);

// Expose all actions and utils to the global window object for inline HTML event handlers
if (typeof window !== 'undefined') {
  Object.assign(window, actions);
  window.S = S;
  window.updateState = updateState;
  window.updateActTypeOpts = updateActTypeOpts;
  window.updateCommunesOpts = updateCommunesOpts;
  window.updateProgramTypeSelect = updateProgramTypeSelect;
  window.onClientStatusChange = onClientStatusChange;
  window.exportData = exportData;
  window.exportToDump = exportToDump;
  window.exportToCSV = exportToCSV;
  window.importData = importData;
  window.importFromDump = importFromDump;
  window.triggerImportDumOrJson = triggerImportDumOrJson;
  window.clearAllData = clearAllData;
  window.toggleLanguage = toggleLanguage;
  window.setLanguage = setLanguage;
  window.fetchMachineTranslation = fetchMachineTranslation;
  window.localizeRenderedDom = localizeRenderedDom;
  window.setCurrentUser = setCurrentUser;
  window.setCurrentStaffUser = setCurrentStaffUser;
  window.R = R;
  window.setClients = setClients;
  window.getClients = getClients;
  window.resolveConflict = resolveConflict;
  window.mergeDatabase = actions.mergeWithSessionAndUser;
}

  // Boot application
  function boot() {
    if (typeof window === 'undefined') return;
    const curLang = S.lang || 'ar';
    applyLanguageToDocument(curLang);
    actions.initDark();

    const isLoggedOut = false;
    if (!isLoggedOut && auth && auth.currentUser) {
      // currentUser state will be set by onAuthStateChanged
    } else {
      stopRealtimeSync();
      window.loginMode = 'login';
      setCurrentUser(null);
      window.setCurrentStaffUser(null);
    }

    initAiAssistantWidget();
    const app = document.getElementById('app');

  // Detect password reset flow from URL on load
  const urlParams = new URLSearchParams(window.location.search);
  const mode = urlParams.get('mode');
  const oobCode = urlParams.get('oobCode');

  if (mode === 'resetPassword' && oobCode) {
    window.loginMode = 'resetPassword';
    window.resetOobCode = oobCode;
    verifyPasswordResetCode(auth, oobCode)
      .then((email) => {
        window.resetEmail = email;
        R();
      })
      .catch((err) => {
        console.error("Invalid or expired reset code:", err);
        actions.showToast("رابط إعادة تعيين كلمة المرور منتهي الصلاحية أو تم استخدامه مسبقاً.", "error");
        window.loginMode = 'login';
        R();
      });
  }

  // Register Global Keyboard Shortcuts
  window.addEventListener('keydown', (e) => {
    // Ctrl + K to focus search
    if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
      e.preventDefault();
      const searchInput = document.getElementById('search-input');
      if (searchInput) {
        searchInput.focus();
      }
    }
    
    // Alt + N for New Client
    if (e.altKey && e.key === 'n') {
      e.preventDefault();
      actions.openModal('addClient');
    }

    // Esc to close modal or clear search
    if (e.key === 'Escape') {
      if (S.modal) {
        actions.closeModal();
      } else {
        const searchInput = document.getElementById('search-input');
        if (searchInput && document.activeElement === searchInput) {
          actions.onQ('');
          searchInput.blur();
        }
      }
    }
  });

  let lastUserUid = undefined;
  let lastUserEmail = undefined;
  let lastUserVerified = undefined;

  onAuthStateChanged(auth, async (user) => {
    const currentUid = user ? user.uid : null;
    const currentEmail = user ? user.email : null;
    
    // Check if user email is verified or logged in via Google/Facebook
    const isVerified = user ? (user.emailVerified || user.providerData.some(p => p.providerId === 'google.com' || p.providerId === 'facebook.com')) : false;

    // Memoize/deduplicate identical auth state callbacks to avoid redundant render loops
    // and multiple active Firestore listeners during rapid token/state triggers on startup.
    if (
      currentUid === lastUserUid &&
      currentEmail === lastUserEmail &&
      isVerified === lastUserVerified
    ) {
      console.log("onAuthStateChanged: Redundant auth state update prevented via memoization");
      return;
    }

    lastUserUid = currentUid;
    lastUserEmail = currentEmail;
    lastUserVerified = isVerified;

    if (user) {
      const activeGerant = {
        uid: user.uid,
        email: user.email,
        displayName: user.displayName || user.email?.split('@')[0] || 'المسؤول العام (Gérant)',
        emailVerified: isVerified,
        role: 'gerant',
        isEmployee: false,
      };
      setCurrentUser(activeGerant);
      // Strictly Online: No local session caching
      
      // If no user profile has logged in yet, show the Users Login Page so user can select their account
      if (!currentStaffUser) {
        S.showStaffPortal = true;
      }
      
      // Trigger initial render immediately with cached or empty state so screen never stays white
      R();
      try {
        await loadDataFromFirestore(user);
        actions.loadGlobalActivities().catch(console.warn);
      } catch (loadErr) {
        console.error("loadDataFromFirestore caught gracefully:", loadErr);
      } finally {
        R();
      }
    } else {
      stopRealtimeSync();
      window.loginMode = 'login';
      setCurrentUser(null);
      setCurrentStaffUser(null);
      setClients([]);
      R();
    }
  });
}

if (typeof window !== 'undefined') {
  boot();

  // Passive, throttled scroll and resize listeners for high-performance list virtualization
  let lastScrollY = 0;
  let scrollTicking = false;

  window.addEventListener('scroll', () => {
    lastScrollY = window.scrollY;
    if (!scrollTicking) {
      window.requestAnimationFrame(() => {
        if (S.view === 'list') {
          const threshold = 50; // pixels to cross before triggering a render
          if (Math.abs(lastScrollY - (S.virtualScrollTop || 0)) > threshold) {
            S.virtualScrollTop = lastScrollY;
          }
        }
        scrollTicking = false;
      });
      scrollTicking = true;
    }
  }, { passive: true });

  window.addEventListener('resize', () => {
    if (S.view === 'list') {
      S.viewportHeight = window.innerHeight;
    }
  }, { passive: true });

  // Reset scroll on navigation away from list
  let lastView = S.view;
  subscribe(() => {
    if (S.view !== lastView) {
      lastView = S.view;
      if (S.view !== 'list' && S.virtualScrollTop !== 0) {
        queueMicrotask(() => {
          if (S.view !== 'list' && S.virtualScrollTop !== 0) {
            S.virtualScrollTop = 0;
          }
        });
      }
    }
  });

  // Strict Online Cloud Sync Network Listeners
  window.addEventListener('online', () => {
    console.log('[Online Sync] Internet connection detected. Resuming live cloud sync...');
    updateState({ isOnline: true });
    if (currentUser && currentUser.uid) {
      startRealtimeSync(currentUser.uid);
      flushSyncQueue();
      actions.loadGlobalActivities().catch(console.warn);
    }
    actions.showToast('🟢 تم الاتصال بالسحابة أونلاين - جاري المزامنة الحية لكافة العمليات.', 'success');
    R();
  });

  window.addEventListener('offline', () => {
    console.warn('[Online Sync] Internet connection lost.');
    updateState({ isOnline: false });
    actions.showToast('🔴 انقطع الاتصال بالإنترنت - نظام PROGILIC CRM يعمل حصرياً عبر السحابة أونلاين.', 'error');
    R();
  });
}

