/**
 * Server Bootstrap & Node Environment Initializer
 * Configures process-level diagnostics and clean server execution boundaries.
 * No fake DOM or window polyfills polluting Node.js global scope.
 */

// Configure default process environment if not explicitly set
if (!process.env.NODE_ENV) {
  process.env.NODE_ENV = 'production';
}

// Global process-level safety handlers
process.on('unhandledRejection', (reason, promise) => {
  console.error('[Server Diagnostic] Unhandled Rejection at:', promise, 'reason:', reason);
});

