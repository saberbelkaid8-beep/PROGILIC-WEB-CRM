/**
 * PROGILIC CRM v3 — Authenticated CRM API Middleware
 * 
 * Cryptographically verifies Firebase ID tokens for protected CRM server endpoints.
 * Validates authenticated user identity and enforces tenant boundary access.
 */

import { getAdminAuth } from '../firebaseAdmin.js';

/**
 * Extracts the Bearer token from the HTTP Authorization header.
 */
export function extractBearerToken(headers = {}) {
  const authHeader = headers.authorization || headers.Authorization || '';
  if (typeof authHeader === 'string' && authHeader.startsWith('Bearer ')) {
    return authHeader.slice(7).trim();
  }
  return null;
}

/**
 * Verifies a Firebase ID token and extracts the authenticated principal.
 * 
 * @param {string} idToken - The JWT ID token from the client
 * @returns {Promise<Object>} The verified decoded token payload
 */
export async function verifyFirebaseIdToken(idToken) {
  if (!idToken || typeof idToken !== 'string' || idToken.trim() === '') {
    const error = new Error('UNAUTHENTICATED: Missing Bearer ID token.');
    error.status = 401;
    throw error;
  }

  const auth = getAdminAuth();
  if (!auth) {
    const error = new Error('SERVICE_UNAVAILABLE: Firebase Admin Auth is not configured on this server.');
    error.status = 503;
    throw error;
  }

  try {
    const decodedToken = await auth.verifyIdToken(idToken.trim());
    return decodedToken;
  } catch (err) {
    const error = new Error(`UNAUTHORIZED: Invalid or expired ID token (${err.code || err.message}).`);
    error.status = 401;
    throw error;
  }
}

/**
 * Validates that an authenticated request is authorized to access the target tenant.
 * Rejects cross-tenant access and unverified identities.
 * 
 * @param {Object} decodedToken - The verified Firebase user token
 * @param {string} targetTenantId - The tenantId being requested
 * @returns {boolean} True if authorized, throws Error if unauthorized
 */
export function assertTenantAccess(decodedToken, targetTenantId) {
  if (!decodedToken || !decodedToken.uid) {
    const error = new Error('UNAUTHENTICATED: Invalid user credentials.');
    error.status = 401;
    throw error;
  }

  if (!targetTenantId || typeof targetTenantId !== 'string') {
    const error = new Error('BAD_REQUEST: Missing target tenantId.');
    error.status = 400;
    throw error;
  }

  // The primary owner tenantId is the Firebase Auth UID
  // For staff users, custom claims or tenantId claim may be present
  const userTenantId = decodedToken.tenantId || decodedToken.uid;

  if (userTenantId !== targetTenantId.trim()) {
    const error = new Error(`FORBIDDEN: Cross-tenant access denied. Principal ${decodedToken.uid} is not authorized for tenant ${targetTenantId}.`);
    error.status = 403;
    throw error;
  }

  return true;
}
