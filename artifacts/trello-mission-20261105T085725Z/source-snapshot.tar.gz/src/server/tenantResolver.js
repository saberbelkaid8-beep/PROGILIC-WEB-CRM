/**
 * PROGILIC CRM × TRELLO INTEGRATION
 * Trusted Server-Side Tenant Resolution Engine
 * 
 * Maps authorized Trello boards & lists to the owning CRM tenant.
 * Strictly ignores any client-supplied, webhook-supplied, or query-param tenant IDs.
 * Fails closed on any missing, unverified, or mismatched configuration.
 */

let dynamicMappingOverrides = null;

/**
 * Normalizes an identifier string (strips whitespace).
 */
function cleanId(id) {
  return typeof id === 'string' ? id.trim() : '';
}

/**
 * Builds the canonical lookup key for board + list scope.
 */
function buildScopeKey(boardId, listId) {
  return `${cleanId(boardId)}::${cleanId(listId)}`;
}

/**
 * Resolves the authenticated CRM tenant for an incoming Trello event
 * based strictly on the verified board ID and list ID.
 * 
 * @param {Object} scope - { boardId, listId }
 * @param {Object} env - Environment variables (defaults to process.env)
 * @returns {Object} Resolution result: { authorized: boolean, tenantId?: string, reason?: string }
 */
export function resolveTenantForTrelloScope(scope = {}, env = process.env) {
  const boardId = cleanId(scope.boardId);
  const listId = cleanId(scope.listId);

  // 1. Mandatory Scope Check: Fail closed if board or list ID is missing
  if (!boardId || !listId) {
    return {
      authorized: false,
      reason: 'MISSING_SCOPE_IDENTIFIERS',
      details: 'Both boardId and listId must be provided to resolve tenant authorization.'
    };
  }

  // 2. Check dynamic/in-memory configuration override (used for testing or runtime registry)
  if (dynamicMappingOverrides instanceof Map) {
    const scopeKey = buildScopeKey(boardId, listId);
    if (dynamicMappingOverrides.has(scopeKey)) {
      const mappedTenant = dynamicMappingOverrides.get(scopeKey);
      if (mappedTenant && typeof mappedTenant === 'string' && mappedTenant.trim() !== '') {
        return {
          authorized: true,
          tenantId: mappedTenant.trim(),
          boardId,
          listId
        };
      }
    }
    return {
      authorized: false,
      reason: 'UNAUTHORIZED_SCOPE_NO_DYNAMIC_MAPPING',
      details: `Scope ${scopeKey} is not registered in the dynamic tenant mapping.`
    };
  }

  // 3. Multi-Tenant JSON Map from Environment (TRELLO_TENANT_MAPPINGS)
  if (env.TRELLO_TENANT_MAPPINGS) {
    try {
      const parsedMappings = typeof env.TRELLO_TENANT_MAPPINGS === 'string'
        ? JSON.parse(env.TRELLO_TENANT_MAPPINGS)
        : env.TRELLO_TENANT_MAPPINGS;

      const scopeKey = buildScopeKey(boardId, listId);
      const mappedTenant = parsedMappings[scopeKey] || parsedMappings[`${boardId}:${listId}`];

      if (mappedTenant && typeof mappedTenant === 'string' && mappedTenant.trim() !== '') {
        return {
          authorized: true,
          tenantId: mappedTenant.trim(),
          boardId,
          listId
        };
      }

      return {
        authorized: false,
        reason: 'UNAUTHORIZED_SCOPE_NOT_IN_MAPPING_TABLE',
        details: `Board/List scope ${scopeKey} was not found in TRELLO_TENANT_MAPPINGS.`
      };
    } catch (err) {
      console.error('[Tenant Resolver] Error parsing TRELLO_TENANT_MAPPINGS:', err.message);
      return {
        authorized: false,
        reason: 'MALFORMED_TENANT_MAPPINGS_CONFIG',
        details: 'Failed to parse TRELLO_TENANT_MAPPINGS JSON configuration.'
      };
    }
  }

  // 4. Single-Integration Deployment Model (Explicit Server Configuration)
  const configuredBoard = cleanId(env.TRELLO_BOARD_ID);
  const configuredList = cleanId(env.TRELLO_LIST_ID);
  const configuredTenant = cleanId(env.TRELLO_TENANT_ID);

  // If server configuration is incomplete, fail closed
  if (!configuredBoard || !configuredList || !configuredTenant) {
    return {
      authorized: false,
      reason: 'SERVER_TENANT_MAPPING_UNCONFIGURED',
      details: 'TRELLO_BOARD_ID, TRELLO_LIST_ID, and TRELLO_TENANT_ID must all be configured on the server.'
    };
  }

  // Verify that board ID strictly matches authorized board
  if (boardId !== configuredBoard) {
    return {
      authorized: false,
      reason: 'UNAUTHORIZED_BOARD_ID',
      details: `Received boardId (${boardId}) does not match authorized TRELLO_BOARD_ID.`
    };
  }

  // Verify that list ID strictly matches authorized list
  if (listId !== configuredList) {
    return {
      authorized: false,
      reason: 'UNAUTHORIZED_LIST_ID',
      details: `Received listId (${listId}) does not match authorized TRELLO_LIST_ID.`
    };
  }

  // Authorization successful
  return {
    authorized: true,
    tenantId: configuredTenant,
    boardId,
    listId
  };
}

/**
 * Registers dynamic mappings for multi-tenant testing or administration.
 * Overrides environment mapping until cleared.
 */
export function setDynamicTenantMappingsForTesting(mappingsMap) {
  dynamicMappingOverrides = mappingsMap;
}

export function resetTenantMappingsForTesting() {
  dynamicMappingOverrides = null;
}
