/**
 * PROGILIC CRM × TRELLO INTEGRATION
 * Secure Server-Side Webhook & API Route Handlers
 */

import crypto from 'crypto';
import { GoogleGenAI, Type } from '@google/genai';
import { TRELLO_AI_SYSTEM_PROMPT } from '../business/trello/trelloAiClassifier.js';
import { syncTrelloChecklistItem, handleTrelloItemDeleted, setServerAdminRepo } from '../business/trello/trelloSyncService.js';
import { resolveTenantForTrelloScope } from './tenantResolver.js';
import { adminRepo } from './firestoreAdminRepository.js';

// Connect server-side Firestore admin repository for webhook execution in production
if (process.env.NODE_ENV !== 'test') {
  setServerAdminRepo(adminRepo);
}

/**
 * Validates Trello Webhook HMAC-SHA1 signatures using constant-time comparison.
 * Fails closed if secret, signature, callback URL, or body is missing.
 */
export function verifyTrelloWebhookSignature(rawBody, signatureHeader, webhookCallbackUrl, webhookSecret) {
  if (!webhookSecret || typeof webhookSecret !== 'string' || webhookSecret.trim() === '') {
    return false; // Fail closed if secret not configured
  }
  if (!signatureHeader || typeof signatureHeader !== 'string' || signatureHeader.trim() === '') {
    return false; // Fail closed if header missing
  }
  if (!webhookCallbackUrl || typeof webhookCallbackUrl !== 'string' || webhookCallbackUrl.trim() === '') {
    return false; // Fail closed if callback URL missing
  }

  try {
    const rawString = typeof rawBody === 'string' ? rawBody : Buffer.isBuffer(rawBody) ? rawBody.toString('utf8') : JSON.stringify(rawBody || '');
    const content = rawString + webhookCallbackUrl;
    const computedBase64 = crypto.createHmac('sha1', webhookSecret).update(content).digest('base64');

    const computedBuf = Buffer.from(computedBase64, 'utf8');
    const headerBuf = Buffer.from(signatureHeader, 'utf8');

    if (computedBuf.length !== headerBuf.length) {
      return false;
    }

    return crypto.timingSafeEqual(computedBuf, headerBuf);
  } catch (err) {
    console.error('[Trello Security] Webhook signature verification failed with error:', err);
    return false;
  }
}

/**
 * Verifies that a webhook event is strictly within the authorized Trello Board and List.
 * Rejects incomplete, missing, or mismatched scope identifiers.
 */
export function isEventInTrelloScope(body, allowedBoardId, allowedListId) {
  if (!allowedBoardId || !allowedListId) {
    return { inScope: false, reason: 'SCOPE_CONFIG_MISSING' };
  }

  if (!body || typeof body !== 'object' || !body.action || !body.action.data) {
    return { inScope: false, reason: 'INVALID_PAYLOAD_STRUCTURE' };
  }

  const data = body.action.data;
  const boardId = data.board?.id;
  const listId = data.list?.id || data.card?.idList || data.checklist?.idList;

  // Incomplete events with unverifiable board or list are strictly rejected
  if (!boardId || !listId) {
    return { inScope: false, reason: 'MISSING_BOARD_OR_LIST_IDENTIFIERS' };
  }

  if (boardId !== allowedBoardId) {
    return { inScope: false, reason: 'UNAUTHORIZED_BOARD', boardId };
  }

  if (listId !== allowedListId) {
    return { inScope: false, reason: 'UNAUTHORIZED_LIST', listId };
  }

  return { inScope: true, boardId, listId };
}

/**
 * Unified request handler for incoming Trello Webhook requests.
 * Compatible with Express, Node http.Server, and dev middleware.
 */
export async function handleTrelloWebhookRequest(rawBody, headers, method, env = process.env, tenantId = null) {
  // 1. Trello Webhook Registration Handshake (HEAD Request)
  if (method === 'HEAD') {
    return { status: 200, headers: { 'Content-Type': 'text/plain' }, body: 'OK' };
  }

  if (method !== 'POST') {
    return { status: 405, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ error: 'METHOD_NOT_ALLOWED' }) };
  }

  // 1b. Maximum Payload Size Guard (512KB limit to prevent denial-of-service)
  const bodyLength = typeof rawBody === 'string' ? Buffer.byteLength(rawBody, 'utf8') : Buffer.isBuffer(rawBody) ? rawBody.length : 0;
  if (bodyLength > 524288) {
    return {
      status: 413,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ error: 'PAYLOAD_TOO_LARGE', message: 'Webhook payload exceeds 512KB limit.' })
    };
  }

  // 2. Strict Signature Verification (Fail Closed)
  const webhookSecret = env.TRELLO_WEBHOOK_SECRET || env.TRELLO_SECRET;
  const callbackUrl = env.TRELLO_CALLBACK_URL || headers['x-trello-callback-url'] || '';
  const signature = headers['x-trello-webhook'];

  const isValidSig = verifyTrelloWebhookSignature(rawBody, signature, callbackUrl, webhookSecret);
  if (!isValidSig) {
    return {
      status: 401,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ error: 'INVALID_OR_MISSING_WEBHOOK_SIGNATURE' })
    };
  }

  // 3. Parse JSON Body
  let parsed;
  try {
    parsed = typeof rawBody === 'string' ? JSON.parse(rawBody) : JSON.parse(rawBody.toString('utf8'));
  } catch (parseErr) {
    return {
      status: 400,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ error: 'MALFORMED_JSON_PAYLOAD' })
    };
  }

  // 4. Dual Scope Verification (Board ID & List ID)
  const allowedBoardId = env.TRELLO_BOARD_ID;
  const allowedListId = env.TRELLO_LIST_ID;
  const scopeCheck = isEventInTrelloScope(parsed, allowedBoardId, allowedListId);

  if (!scopeCheck.inScope) {
    return {
      status: 200,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status: 'IGNORED_OUT_OF_SCOPE', reason: scopeCheck.reason })
    };
  }

  // 5. Trusted Server-Side Tenant Resolution (Fail closed, no arbitrary fallbacks)
  const tenantRes = resolveTenantForTrelloScope({ boardId: scopeCheck.boardId, listId: scopeCheck.listId }, env);
  const targetTenantId = tenantId || (tenantRes.authorized ? tenantRes.tenantId : null);

  if (!targetTenantId) {
    return {
      status: 403,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        error: 'UNAUTHORIZED_TENANT_SCOPE',
        reason: tenantRes.reason || 'NO_TRUSTED_TENANT_MAPPING',
        details: tenantRes.details
      })
    };
  }

  // 6. Relevant Checklist Action Dispatch
  const actionType = parsed.action?.type;
  const actionData = parsed.action?.data;
  const card = actionData?.card;
  const board = actionData?.board;
  const checkItem = actionData?.checkItem;

  if (actionType === 'deleteCheckItem' && checkItem?.id) {
    const delRes = await handleTrelloItemDeleted(targetTenantId, checkItem.id);
    return {
      status: 200,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status: 'DELETED_AT_SOURCE_PRESERVED_IN_CRM', result: delRes })
    };
  }

  if (checkItem && checkItem.id) {
    const syncRes = await syncTrelloChecklistItem(targetTenantId, checkItem, card, board);
    if (syncRes && syncRes.status === 'FAILED') {
      const isLockContention = syncRes.reason === 'CONCURRENT_PROCESSING_ACTIVE';
      return {
        status: isLockContention ? 503 : 500,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          error: 'SYNC_PROCESSING_FAILED',
          reason: syncRes.reason || syncRes.error || 'INTERNAL_ERROR',
          retryable: true,
          syncResult: syncRes
        })
      };
    }
    return {
      status: 200,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status: 'PROCESSED', syncResult: syncRes })
    };
  }

  return {
    status: 200,
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ status: 'IGNORED_UNRELATED_ACTION', actionType })
  };
}

/**
 * Server-side AI Classification using Gemini 2.5 Flash
 */
export async function handleTrelloAiClassify(reqBody, apiKey) {
  const { itemText, cardContext, checklistItem } = reqBody;
  if (!apiKey) {
    throw new Error('GEMINI_API_KEY_MISSING');
  }

  const ai = new GoogleGenAI({ apiKey, httpOptions: { headers: { 'User-Agent': 'aistudio-build' } } });
  const prompt = `
Understand the following Trello checklist item from the "PROGRAMME DE SERVICES" list:
Card Title: "${cardContext?.cardName || ''}"
Checklist Item: "${itemText}"
Checklist State: "${checklistItem?.state || 'incomplete'}"
`;

  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash',
    contents: prompt,
    config: {
      systemInstruction: TRELLO_AI_SYSTEM_PROMPT,
      responseMimeType: 'application/json',
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          rawText: { type: Type.STRING },
          actionNature: { type: Type.STRING, description: 'installation | technical_issue | requirement | training | assistance | contact | service' },
          actionDescription: { type: Type.STRING },
          title: { type: Type.STRING },
          extractedInterventionMedium: { type: Type.STRING, nullable: true },
          contextEvidence: { type: Type.STRING },
          statedOutcome: { type: Type.STRING, description: 'completed | in_progress | unspecified' },
          confirmedResolved: { type: Type.BOOLEAN },
          outcomeEvidence: { type: Type.STRING, nullable: true },
          confidence: { type: Type.NUMBER },
          uncertainties: { type: Type.ARRAY, items: { type: Type.STRING } },
          customer: {
            type: Type.OBJECT,
            properties: {
              rawName: { type: Type.STRING },
              phone: { type: Type.STRING, nullable: true },
              company: { type: Type.STRING, nullable: true },
              wilaya: { type: Type.STRING, nullable: true },
              isExistingRealWorldClient: { type: Type.BOOLEAN }
            },
            required: ['rawName']
          }
        },
        required: ['rawText', 'actionNature', 'contextEvidence', 'confirmedResolved', 'confidence', 'uncertainties', 'customer']
      }
    }
  });

  return JSON.parse(response.text);
}
